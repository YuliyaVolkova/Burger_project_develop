
 
var isMobile = ()=> {

    return 6
  }

export default isMobile;
